PCB Pilot fabrication package - Remote interphone gate opener — ESP32-S3 + relay dry contact, USB-C 5V

Board:      106 x 65 mm
Stack:      2-layer FR-4, 1.6 mm finished thickness, 1 oz copper
            L1 = top copper, L2 = bottom copper. All holes plated (PTH).

Files:
  remote-interphone-gate-opener-esp32-s3-relay-dry.GTL
  remote-interphone-gate-opener-esp32-s3-relay-dry.GBL
  remote-interphone-gate-opener-esp32-s3-relay-dry.GTS
  remote-interphone-gate-opener-esp32-s3-relay-dry.GBS
  remote-interphone-gate-opener-esp32-s3-relay-dry.GTO
  remote-interphone-gate-opener-esp32-s3-relay-dry.GBO
  remote-interphone-gate-opener-esp32-s3-relay-dry.GKO
  remote-interphone-gate-opener-esp32-s3-relay-dry.DRL
  remote-interphone-gate-opener-esp32-s3-relay-dry.GTP
  remote-interphone-gate-opener-esp32-s3-relay-dry.GBP
  PCB-README.txt

Design rules used (mm):
  Trace width:        0.8 nominal, 0.25 minimum (neck-down)
  Clearance:          0.3
  Via:                1.2 pad / 0.6 drill
  Solder mask expansion: 0.05 per side
  Silkscreen width:   0.15
  Copper to edge:     0.5

Nets: 14
Components: 20
Drilled holes: 118

Notes:
  - Gerbers are RS-274X, millimetres, 4.6 format.
  - Solder mask files contain the OPENINGS; vias tented (no mask opening).
  - Bottom copper carries a ground pour on net "0", direct connect
    (no thermal reliefs). Hand-soldering a pin that lands in the pour needs more
    heat than the others - the plane sinks it. Reflow is unaffected.
  - Electrolytic capacitor and diode polarity per silkscreen.

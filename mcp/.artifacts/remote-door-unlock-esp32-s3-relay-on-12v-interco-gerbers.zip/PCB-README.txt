PCB Pilot fabrication package - Remote door unlock — ESP32-S3 + relay on 12V intercom supply, TP4056 battery failover

Board:      110 x 74 mm
Stack:      2-layer FR-4, 1.6 mm finished thickness, 1 oz copper
            L1 = top copper, L2 = bottom copper. All holes plated (PTH).

Files:
  remote-door-unlock-esp32-s3-relay-on-12v-interco.GTL
  remote-door-unlock-esp32-s3-relay-on-12v-interco.GBL
  remote-door-unlock-esp32-s3-relay-on-12v-interco.GTS
  remote-door-unlock-esp32-s3-relay-on-12v-interco.GBS
  remote-door-unlock-esp32-s3-relay-on-12v-interco.GTO
  remote-door-unlock-esp32-s3-relay-on-12v-interco.GBO
  remote-door-unlock-esp32-s3-relay-on-12v-interco.GKO
  remote-door-unlock-esp32-s3-relay-on-12v-interco.DRL
  remote-door-unlock-esp32-s3-relay-on-12v-interco.GTP
  remote-door-unlock-esp32-s3-relay-on-12v-interco.GBP
  PCB-README.txt

Design rules used (mm):
  Trace width:        0.8 nominal, 0.25 minimum (neck-down)
  Clearance:          0.3
  Via:                1.2 pad / 0.6 drill
  Solder mask expansion: 0.05 per side
  Silkscreen width:   0.15
  Copper to edge:     0.5

Nets: 23
Components: 36
Drilled holes: 144

Notes:
  - Gerbers are RS-274X, millimetres, 4.6 format.
  - Solder mask files contain the OPENINGS; vias tented (no mask opening).
  - Bottom copper carries a ground pour on net "0", direct connect
    (no thermal reliefs). Hand-soldering a pin that lands in the pour needs more
    heat than the others - the plane sinks it. Reflow is unaffected.
  - Electrolytic capacitor and diode polarity per silkscreen.
